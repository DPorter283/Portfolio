# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import numpy as np
import pandas as pd
import nltk
##nltk.download('punkt') 
import sklearn as sk
nltk.download('stopwords') 
import sklearn.feature_extraction.text as fe
import tokenize
from nltk.corpus import stopwords 
from nltk.stem.wordnet import WordNetLemmatizer
import string
nltk.download('wordnet')
import gensim
import pyLDAvis
import pyLDAvis.gensim
import matplotlib.pyplot as plt
nltk.download('abc')
import warnings
from gensim.models.coherencemodel import CoherenceModel
import collections
import seaborn as sns
from pandas import DataFrame
%matplotlib inline

warnings.filterwarnings("ignore",category=DeprecationWarning)


df = pd.read_csv('https://query.data.world/s/7hxuvrghwnkx5myrbygx2tji3n67gg', encoding = 'ansi')

## Remove songs without lyrics
df = df[df['lyrics'] != 'Error: Could not find lyrics.']


## Drop unnecessary columns
df = df.drop(['year', 'date', 'simple_title', 'main_artist', 'spotify_link', 'spotify_id' , 'video_link',  'analysis_url','change', 'genre' ], axis = 1)

## Drop columns with undefined genres

testDF2 = df[df['broad_genre'] == ('unknown')]
testDF = df[df['broad_genre'].isnull()]
testFrames = (testDF,testDF2)
completeTestDF = pd.concat(testFrames)
completeTestDF = completeTestDF[completeTestDF['acousticness'] != 'unknown']

df = df[df['broad_genre'] != 'unknown']
df = df[~df.isin(testDF)].dropna()
df = df[~df.isin(testDF2)].dropna()

## covert broad_genre & artist column to a factor for visualization
df["broad_genre"] = df["broad_genre"].astype('category')
df["artist"] = df["artist"].astype('category')



export_csv = df.to_csv(r'C:\Users\Damon\Documents\dataframe.csv')

## Tokenize words and Create TDF
def tokens(x):
    return x.split(',')

tfidf = fe.TfidfVectorizer(tokenizer=tokens, stop_words = 'english')
docs = df['lyrics']
tfs = tfidf.fit_transform(docs)

## Clean documents
sWords = stopwords.words('english')
sWords.extend(['yeah', 'im', 'la','oh','da', 'ooh', 'ah' ])
stop = set(sWords)

## Stems words, removes punct, remove stop words
exclude = set(string.punctuation) 
lemma = WordNetLemmatizer()
def clean(doc):
    stop_free = " ".join([i for i in doc.lower().split() if i not in stop])
    punc_free = ''.join(ch for ch in stop_free if ch not in exclude)
    normalized = " ".join(lemma.lemmatize(word) for word in punc_free.split())
    return normalized
doc_clean = [clean(doc).split() for doc in docs]




# Importing Gensim

from gensim import corpora

dictionary = corpora.Dictionary(doc_clean)

# Creating the term dictionary of our courpus, where every unique term is assigned an index. dictionary = corpora.Dictionary(doc_clean)

# Converting list of documents (corpus) into Document Term Matrix using dictionary prepared above.
doc_term_matrix = [dictionary.doc2bow(doc) for doc in doc_clean]


Lda = gensim.models.ldamodel.LdaModel

# Running and Trainign LDA model on the document term matrix.
ldamodel = Lda(doc_term_matrix, num_topics=20, id2word = dictionary, random_state = 100, passes=20, per_word_topics = True)
pprint(ldamodel.print_topics())
doc_lda = ldamodel[doc_term_matrix]

## Measure Complexity of the model and Coherence Score
print('\nPerplexity: ', ldamodel.log_perplexity(doc_term_matrix))

coherence_model_lda = CoherenceModel(model = ldamodel, texts = doc_term_matrix, dictionary = dictionary, coherence = 'c_v')
print('\nCoherence Score: ',coherence_model_lda)


##Viz. If you want to see this visualization, please open up jupyter notebook and find the lda.html.
pyLDAvis.enable_notebook()
vis = pyLDAvis.gensim.prepare(ldamodel,doc_term_matrix,dictionary)
pyLDAvis.display(vis)
pyLDAvis.save_html(vis, 'lda.html')

## more Viz
